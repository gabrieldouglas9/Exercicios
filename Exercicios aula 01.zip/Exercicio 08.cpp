#include<stdio.h>

float f, c;

main(){
	printf("CONVERSOR DE TEMPERATURA");
	printf("\nQual e a temperatura em graus Celsius: ");
	scanf("%f", &c);
	f = (9 * c + 160) / 5;
	printf("\nO valor convertido para Fahrenheit e %.1f F",f);
}
