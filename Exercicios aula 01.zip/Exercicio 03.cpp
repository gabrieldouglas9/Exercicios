#include<stdio.h>

float venda, comissao, comissao1;

main(){
	printf("CALCULADOR DE COMISSOES");
	printf("\nQual o valor da venda? ");
	scanf("%f", &venda);
	comissao = venda * 0.95;
	comissao1 = venda - comissao;
	printf("%f",comissao1);
}
