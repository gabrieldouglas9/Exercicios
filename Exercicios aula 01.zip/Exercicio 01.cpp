#include<stdio.h>

int nasc;

main(){
	printf("CALCULARDOR DE IDADE");
	printf("\nDigite seu ano de nascimento: ");
	scanf("%i", &nasc);
	printf("\nVoce tem %i anos\n", 2026 - nasc);
	
}
