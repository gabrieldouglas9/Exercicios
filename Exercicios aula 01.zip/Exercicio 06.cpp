#include<stdio.h>

int n;
int quad;

main(){
	printf("NUMERO AO QUADRADO");
	printf("\nDigite um numero: ");
	scanf("%i", &n);
	quad = n * n;
	printf("\nO %i ao quadrado e igual a %i", n, quad);
}
