#include<stdio.h>

float total, produto, pagamento, troco;
int quantidade;

main(){
	printf("MERCADO");
	printf("\nQual e o valor do produto: ");
	scanf("%f", &produto);
	printf("Qual a quantidade: ");
	scanf("%i", &quantidade);
	total = produto * quantidade;
	printf("\nO total da sua compra ficou em %.2f R$",total);
	printf("Quanto vai pagar: ");
	scanf("%f", &pagamento);
	troco = pagamento - total;
	printf("\nO seu troco sera de %.2f", troco);
}
