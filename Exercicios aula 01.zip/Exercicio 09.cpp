#include<stdio.h>

float f, c;

main(){
	printf("CONVERSOR DE TEMPERATURA");
	printf("\nQual e a temperatura em Fahrenheit: ");
	scanf("%f", &f);
	c = (f - 32) * (5.0/9.0);
	printf("\nO valor convertido para graus Celsius e %.1f C",c);
}
