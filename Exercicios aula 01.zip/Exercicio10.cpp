#include<stdio.h>

int a, b, A, B;

main(){
	printf("TROCA DE VALORES");
	printf("\nDigite o valor de A: ");
	scanf("%i", &a);
	printf("\nDigite o valor de B: ");
	scanf("%i", &b);
	A = b;
	B = a;
	printf("\nAgora o valor de A e igual a %i",A);
	printf("\nAgora o valor de B e igual a %i",B);
}
