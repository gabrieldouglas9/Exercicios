#include<stdio.h>

float dinheiro, dol, real;

main(){
	printf("CONVERSOR DE MOEDAS");
	printf("\nDigite o valor em DOLARES: ");
	scanf("%f", &dinheiro);
	printf("\nQuanto esta a cotacao do DOLAR atualmente: ");
	scanf("%f", &dol);
	real = dinheiro * dol;
	printf("\nConvertando voce tem %.2f R$",real);
	
}
