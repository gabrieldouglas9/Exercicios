#include<stdio.h>

float ano, idade;

main(){
	printf("NATACAO");
	printf("\nDigite seu ano de nascimento: ");
	scanf("%f", &ano);
	idade = 2026 - ano;
	if (idade <= 5 ){
		printf("Voce tem %.f anos", idade);
		printf("\nPortanto pertence a categoria FRALDINHA!");
	}
	else if (idade >= 5 and idade <=7){
		printf("Voce tem %.f anos", idade);
		printf("\nPortanto pertence a categoria PRE-MIRIM!");
	}
	else if (idade >= 8 and  idade <= 11){
		printf("Voce tem %.f anos", idade);
		printf("\nPortanto pertence a categoria MIRIM!");
	}
	else if (idade >= 12 and idade <= 13){
		printf("Voce tem %.f anos", idade);
		printf("\nPortanto pertence a categoria INFANTIL!");
	}
	else if (idade >= 14 and idade <= 17){
		printf("Voce tem %.f anos", idade);
		printf("\nPortanto pertence a categoria JUVENIL!");
	}
	else{
		printf("Voce tem %.f anos", idade);
		printf("\nPortanto pertence a categoria ADULTO!");
	}
}
