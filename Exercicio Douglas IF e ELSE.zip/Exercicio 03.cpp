#include<stdio.h>

int valor;

main(){
	printf("POSITIVO/NEGATIVO");
	printf("\nDigite um numero: ");
	scanf("%i", &valor);
	if (valor >=0 ){
		printf("O VALOR E POSITIVO");
	}
	else{
		printf("O VALOR E NEGATIVO");
	}
	if (valor%2==0){
		printf("\nESSE VALOR E PAR");
	}
	else {
		printf("\nESSE VALOR E IMPAR");
	}
}
