#include<stdio.h>

float meio, menor, maior, n1, n2, n3;

main(){
	printf("LEITOR DE VALORES");
	printf("\nDigite o primeiro valor: ");
	scanf("%f", &n1);
	printf("Digite o segundo valor: ");
	scanf("%f", &n2);
	printf("Digite o terceiro valor: ");
	scanf("%f", &n3);
	if (n1 > n2 and n1 > n3){
		maior = n1;
	}
	else if (n2 > n1 and n2 > n3){
		maior = n2;
	}
	else if (n3 > n1 and n3 > n2){
		maior = n3;
	}
	if (n1 < n2 and n1 < n3){
		menor = n1;
	}
	else if (n2 < n1 and n2 < n3){
		menor = n2;
	}
	else if (n3 < n1 and n3 < n2){
		menor = n3;
	}
	if (n1 > menor and n1 < maior){
		meio = n1;
	}
	else if (n2 > menor and n2 < maior){
		meio = n2;
	}
	else if (n3 > menor and n3 < maior){
		meio = n3;
	}
	printf("\nO maior numero e o %.f", maior);
	printf("\nO valor do meio e o %.f", meio);
	printf("\nO menor numero e o %.f", menor);
}
