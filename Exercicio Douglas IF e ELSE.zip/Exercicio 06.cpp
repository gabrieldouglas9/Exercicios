#include<stdio.h>

float num1, num2, diferenca;

main(){
	printf("DIFERENCA");
	printf("\nDIGITE UM NUMERO: ");
	scanf("%f", &num1);
	printf("DIGITE OUTRO NUMERO: ");
	scanf("%f", &num2);
	if (num1 >= num2){
		diferenca = num1 - num2;
		printf("\nA diferenca entre os numeros e de %.2f", diferenca);
	}
	else{
		diferenca = num2 - num1;
		printf("\nA diferenca entre os numeros e de %.2f", diferenca);
	}
}
