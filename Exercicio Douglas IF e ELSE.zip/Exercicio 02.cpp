#include<stdio.h>

int valor;

main(){
	printf("LEITURA DE VALOR");
	printf("\nDigite qualquer valor: ");
	scanf("%i", &valor);
	if (valor >= 0){
		valor = valor * - 1;
		printf("O novo valor e %i", valor);
	}
	else {
		valor = valor * -1;
		printf("O novo valor e %i", valor);
	}
}
