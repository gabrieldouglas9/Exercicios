#include<stdio.h>

float luz;

main(){
	printf("CONTA DE LUZ");
	printf("\nDigite o valor da sua conta de luz: ");
	scanf("%f", &luz);
	if (luz >= 50.0) {
		printf("VOCE ESTA GASTANDO MUITO!");
	}		
	else {
		printf("SEU GASTO FOI NORMAL!");
	}
}
