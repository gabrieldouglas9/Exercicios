#include<stdio.h>

float p, e, m;

main(){
	printf("CALCULO DE PESO");
	printf("\nDigite quantos Kg: ");
	scanf("%f", &p);
	if (p >= 50){
		e = p - 50;
		printf("\nVoce excedeu %.2f Kg de peixe", e);
		m = e * 4;
		printf("\nVoce devera pagar uma multa de R$ %.2f", m);
	}
	else{
		printf("\nVoce esta dentro da regulamentacao");
	}
}
