#include<stdio.h>

float sexo, h, peso;

main(){
	printf("PESO IDEAL");
	printf("\nDigite 1 para HOMENS");
	printf("\nDigite 2 para MULHERES             ");
	scanf("%f", &sexo);
	printf("Digite sua altura: ");
	scanf("%f", &h);
	if (sexo == 1 ){
		peso = (72.7*h) - 58;
		printf("Sendo HOMEM o seu peso ideal seria de %.2f Kg", peso);
	}
	else {
		peso = (62.1*h) - 44.7;
		printf("Sendo MULHER o seu peso ideal seria de %.2f Kg", peso);
	}
}
