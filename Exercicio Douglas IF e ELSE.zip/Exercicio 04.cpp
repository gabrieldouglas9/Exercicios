#include<stdio.h>

float combustivel, litros, valor;

main(){
	printf("TANQUE COMBUSTIVEL");
	printf("\nPreco Gasolina: R$ 6.50");
	printf("\nPreco Alcool:   R$ 4.50");
	printf("\nDigite {1} para utilizar Gasolina");
	printf("\nDigite {2} para utilizar Alcool          ");
	scanf("%f", &combustivel);
	printf("\nDigite quantos Litros: ");
	scanf("%f", &litros);
	if (combustivel == 1){
		valor = litros * 6.50;
		printf("\nO total da sua compra foi de R$ %.2f", valor);
	}
	else{
		valor = litros * 4.50;
		printf("\nO total da sua compra foi de R$%.2f", valor);
	}
}
