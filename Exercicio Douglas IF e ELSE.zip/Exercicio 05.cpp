#include<stdio.h>

float nmacas, valor;

main(){
	printf("VENDAS MACAS");
	printf("\nMACA: 		            R$ 1.30");
	printf("\nMACA a partir de uma duzia: R$ 1.00");
	printf("\nDigite Quantas macas deseja: ");
	scanf("%f", &nmacas);
	if (nmacas >=12){
		valor = nmacas * 1;
		printf("O valor de suas macas foi de R$ %.2f", valor);
	}
	else {
		valor = nmacas * 1.3;
		printf("O valor de suas macas foi de R$ %.2f", valor);
	}
}
