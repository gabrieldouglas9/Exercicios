#include<stdio.h>

float n1, n2, n3, n4, media;

main(){
	printf("MEDIA NOTAS 0-10");
	printf("\nDigite sua primeira nota: ");
	scanf("%f", &n1);
	printf("Digite sua segunda nota: ");
	scanf("%f", &n2);
	printf("Digite a sua terceira nota: ");
	scanf("%f", &n3);
	printf("Digite sua quarta nota: ");
	scanf("%f", &n4);
	media = (n1 + n2 + n3 + n4) / 4;
	if (media >= 6){
		printf("\nA sua media foi de %.2f", media);
		printf("\nPARABENS VOCE FOI APROVADO!");
	}
	else {
		printf("\nA sua media foi de %.2f", media);
		printf("\nINFELIZMENTE VOCE NAO FOI APROVADO!");
	}
}
