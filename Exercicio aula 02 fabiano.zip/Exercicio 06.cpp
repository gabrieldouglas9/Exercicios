#include<stdio.h>

float kwh, precokwh, taxabandeira, iluminacao, demaistaxas, custoenergia, valortotal, customediokwh, custoanual;

main(){
	printf("CONTA DE ENERGIA");
	printf("\nDigite seu consumo de Kw/h: ");
	scanf("%f", &kwh);
	printf("Digite o preco do Kw/h: ");
	scanf("%f", &precokwh);
	printf("Digite a taxa bandeira: ");
	scanf("%f", &taxabandeira);
	printf("Digite o valor da iluminacao publica: ");
	scanf("%f", &iluminacao);
	printf("Digite as demais taxas: ");
	scanf("%f", &demaistaxas);
	custoenergia = kwh * precokwh;
	valortotal = custoenergia + taxabandeira + demaistaxas + iluminacao;
	custoanual = valortotal * 12;
	customediokwh = 1;
	printf("O custo da sua energia sera de %.2f R$", custoenergia);
	printf("\nO valor total do mes sera de %.2f R$", valortotal);
	printf("\nCusto medio de Kw/h e de %.2f R$", customediokwh);
	printf("\nO custo anual sera de %.2f R$", custoanual);
}
