#include<stdio.h>

float km, litros, preco, media, consumomedio, custo, custoporkm, diferenca;

main(){
	printf("CONTROLE DE COMBUSTVEL");
	printf("\nQuantos Kms andou: ");
	scanf("%f", &km);
	printf("Quantos litros de gasolina consumiu: ");
	scanf("%f", &litros);
	printf("Qual e o preco da gasolina: ");
	scanf("%f", &preco);
	printf("Qual e a media de consumo por km: ");
	scanf("%f", &media);
	consumomedio = km / litros;
	custo = litros * preco;
	custoporkm =  custo / km;
	diferenca = media - consumomedio;
	printf("O consumo medio foi de %.2f Km", consumomedio);
	printf("\nO custo total foi de %.2f R$", custo);
	printf("\nO custo por 1 Km rodado foi de %.2f", custoporkm);
	printf("\nA diferenca de estimativa foi de %.2f Km", diferenca);
	if (diferenca <= 0 ){
		printf("\nVOCE ATINGIU A META PARABENS");
	}
	else
		printf("\nVOCE NAO ATINGIU A META");
}
