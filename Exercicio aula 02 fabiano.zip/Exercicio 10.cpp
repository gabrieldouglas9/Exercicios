#include<stdio.h>

float basico, profissional, empresarial, desconto, taxa, imposto, receitabasico, receitaprofissional, receitaempresarial, receitabruta, receitadesconto, receitaliquida;

main(){
	printf("Plataforma SaaS brasileira");
	printf("\nQual a quantidade de clientes do plano Basico : ");
	scanf("%f", &basico);
	printf("Qual a quantidade de clientes no plano Profissional: ");
	scanf("%f", &profissional);
	printf("Qual a quantidade de clientes no plano Empresarial: ");
	scanf("%f", &empresarial);
	printf("Percentual de desconto: ");
	scanf("%f", &desconto);
	printf("Percentual de taxa de processamento: ");
	scanf("%f", &taxa);
	printf("Percentual de impostos: ");
	scanf("%f", &imposto);
	receitabasico = basico * 39.90;
	receitaprofissional = profissional * 89.90;
	receitaempresarial = empresarial * 199.90;
	receitabruta = receitaempresarial + receitaprofissional + receitabasico;
	receitadesconto = receitabruta - (receitabruta*(desconto/100));
	receitaliquida = receitadesconto - (receitabruta*taxa/100) - (receitabruta*imposto/100);
	printf("A receita do plano basico foi de %.2f R$", receitabasico);
	printf("\nA receita do plano Profissional foi de %.2f R$", receitaprofissional);
	printf("\nA receita do plano Empresarial foi de %.2f R$", receitaempresarial);
	printf("\nA receita bruta foi de %.2f R$", receitabruta);
	printf("\nCom o desconto a receita foi para %.2f R$", receitadesconto);
	printf("\nA receita liquida foi de %.2f R$", receitaliquida);
}
