#include<stdio.h>

float real, dolar, euro, valordolar, valoreuro, valordolartaxa, valoreurotaxa;

main(){
	printf("CONVERSOR DE MOEDAS");
	printf("\nDigite o valor em REAL: ");
	scanf("%f", &real);
	printf("Digite a Cotacao do DOLAR: ");
	scanf("%f", &dolar);
	printf("Digite a Cotacao do EURO: ");
	scanf("%f", &euro);
	valordolar = real * dolar;
	valoreuro = real * euro;
	valordolartaxa = (valordolar * 0.015) + valordolar;
	valoreurotaxa = (valoreuro * 0.015) + valoreuro;
	printf("\nVoce tem %.2f R$",real);
	printf("\nVoce tem %.2f U$ (Adicionada a taxa de 1.5)", valordolartaxa);
	printf("\nVoce tem %.2f EUROS  (Adicionada a taxa de 1.5)", valoreurotaxa);
}
