#include<stdio.h>

float horas, valorhoras, horasextras, percentual, taxa, horasnormais, taxaplataforma, taxaplataformal, salliquido, faturamentobruto, totalhorasextras, valor, valorporcentagem, valorhorasextras;

main(){
	printf("CALCULO DE SALARIO");
	printf("\nDigite as horas trabalhadas: ");
	scanf("%f", &horas);
	printf("\nDigite o valor das horas: ");
	scanf("%f", &valorhoras);
	printf("Digite as suas horas-extras: ");
	scanf("%f", &horasextras);
	printf("Qual sera o percentual a mais de horas extras: ");
	scanf("%f", &percentual);
	printf("Qual sera a taxa da plataforma em PORCENTAGEM: ");
	scanf("%f", &taxa);
	horasnormais = horas * valorhoras;
	valorporcentagem = percentual/100;
	valor = horasextras * valorhoras;
	totalhorasextras = valor + (valorporcentagem * valor);
	faturamentobruto = totalhorasextras + horasnormais;
	taxaplataforma =  taxa/100;
	taxaplataformal =  taxaplataforma * faturamentobruto;
	salliquido = faturamentobruto - taxaplataformal;
	printf("As horas normais lhe renderam %.2f", horasnormais);
	printf("\nO valor das horas extras foram de %.2f", totalhorasextras);
	printf("\nO faturamento Bruto foi de %.2f", faturamentobruto);
	printf("\nO valor liquido sera de %.2f", salliquido);
}
