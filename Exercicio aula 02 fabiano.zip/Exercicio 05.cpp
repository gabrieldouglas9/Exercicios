#include<stdio.h>

float trabalho, projeto, prova, seminario, media;

main(){
	printf("CALCULADOR DE NOTAS");
	printf("\nQual foi a nota do seu Trabalho: ");
	scanf("%f", &trabalho);
	printf("Digite sua nota do seu Projeto: ");
	scanf("%f", &projeto);
	printf("Digite a nota de sua Prova: ");
	scanf("%f", &prova);
	printf("Digite a nota do seu Seminario: ");
	scanf("%f", &seminario);
	media = (trabalho * 0.2) + (projeto * 0.3) + (prova * 0.3) + (seminario * 0.2);
	if (media >= 7.0){
		printf("\nAprovado");
	}
	else if (media>= 5.0){
		printf("\nFicou de recuperacao");
	}
	else{
		printf("\nReprovado");
	}
	printf("\nSua media foi de %.2f", media);
}
