#include<stdio.h>

float aluguel, alimentacao, transporte, internet, lazer, material, gmensal, ganual, gdiario, porcentoaluguel, aluguelanual;

main(){
	printf("CALCULADOR DE GASTOS");
	printf("\nDigite o seu aluguel: ");
	scanf("%f", &aluguel);
	printf("Digite a sua alimentacao: ");
	scanf("%f", &alimentacao);
	printf("Digite seu transporte: ");
	scanf("%f", &transporte);
	printf("Digite sua internet: ");
	scanf("%f", &internet);
	printf("Digite o lazer: ");
	scanf("	%f", &lazer);
	printf("Digite seu material academico: ");
	scanf("%f", &material);
	gmensal = (aluguel + alimentacao + transporte + internet + lazer + material);
	ganual = gmensal * 12;
	gdiario = gmensal / 30;
	aluguelanual = aluguel * 12;
	porcentoaluguel = (aluguelanual / ganual) * 100;
	printf("\nO seu gasto mensal e %.2f R$", gmensal);
	printf("\nO seu gasto anual e de %.2f R$", ganual);
	printf("\nO seu gasto diario e de %.2f R$", gdiario);
	printf("\nEstimasse que %.f porcento dos gastos anuais foram de aluguel",porcentoaluguel);
}
