#include<stdio.h>

float km, kmporl, precocombustivel, valpedagio, passageiro, combustivel, custocombustivel, custoviagem, custopassageiro; 

main(){
	printf("VIAGEM MARINGA � SAO PAULO");
	printf("\nDigite a distancia em Km: ");
	scanf("%f", &km);
	printf("Digite o consumo de KM/L: ");
	scanf("%f", &kmporl);
	printf("Digite o preco do combustivel em L: ");
	scanf("%f", &precocombustivel);
	printf("Digite o valor dos pedagios: ");
	scanf("%f", &valpedagio);
	printf("Quantos passageiros vao na viagem: ");
	scanf("%f", &passageiro);
	combustivel = km / kmporl;
	custocombustivel = combustivel * precocombustivel;
	custoviagem = custocombustivel + valpedagio;
	custopassageiro = custoviagem / passageiro;
	printf("A quantidade necessaria de combustivel e de %.2f L", combustivel);
	printf("\nO valor do combustivel e de %.2f R$", custocombustivel);
	printf("\nO custo total da viagem e de %.2f R$", custoviagem);
	printf("\nO custo por passageiro e de %.2f R$", custopassageiro);	
}
