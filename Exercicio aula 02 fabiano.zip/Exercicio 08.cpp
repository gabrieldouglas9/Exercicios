#include<stdio.h>

float estudante, profissional, empresarial, participantes, receitaestudante, receitaprofissional, receitaempresarial, receitatotal, precomedio, receitatotall;
main(){
	printf("EVENTO DE TECHNOLOGIA");
	printf("\nEstudante R$ 50,00");
	printf("\nProfissional R$ 120,00");
	printf("\nEmpresarial R$ 250,00");
	printf("\nQuantos ingressos de estudantes: ");
	scanf("%f", &estudante);
	printf("Quantos ingressos profissionais: ");
	scanf("%f", &profissional);
	printf("Quantos ingressos empresariais: ");
	scanf("%f", &empresarial);
	participantes = estudante + profissional + empresarial;
	receitaestudante = estudante * 50;
	receitaprofissional =  profissional * 120;
	receitaempresarial = empresarial * 250;
	receitatotal = receitaempresarial + receitaprofissional + receitaestudante;
	precomedio = receitatotal / participantes;
	if (receitatotal >= 20000.0){
		receitatotall = (receitatotal - receitatotal*0.05);
	}
	printf("O evento teve %.f participntes", participantes);
	printf("\nA receita dos ingressos de estudantes foram de %.2f R$", receitaestudante);
	printf("\nA receita dos ingressos profissionais foram de %.2f R$", receitaprofissional);
	printf("\nA receita dos ingressos empresariais foram de %.2f R$", receitaempresarial);
	printf("\nA receita total do evento foi de %.2f R$", receitatotall);
	printf("\nO preco medio por pessoa foi de %.2f R$", precomedio);
}
