#include<stdio.h>


float despercentualinss, despercentualir, salbruto, salliquido, percentualinss, percentualir, inss, ir ;
	
	
main(){
	printf("Digite seu salario bruto: ");
	scanf("%f", &salbruto);
	printf("Digite o percentual de INSS: ");
	scanf("%f", &inss);
	printf("Digite o percetual de IR: ");
	scanf("%f", &ir);
	percentualinss = inss / 100.0;
	percentualir = ir / 100.0;
	despercentualinss = salbruto * percentualinss;
	despercentualir = salbruto * percentualir;
	salliquido = salbruto - despercentualinss - despercentualir;
	printf("O seu salario liquido e igual a %.2f ", salliquido);
}
