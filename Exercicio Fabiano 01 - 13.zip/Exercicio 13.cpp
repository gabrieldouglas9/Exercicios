#include<stdio.h>

float programador, horasprogramador, custohora, infraestrutura, software, custocliente, imposto, comissao, maodeobra, custototal, lucrobruto, percentulimposto, percentualcomissao, lucroliquido, margemlucro, percentualimposto;

main(){
	printf("STARTUP MARINGAENSE");
	printf("\nDigite o numero de programadores: ");
	scanf("%f", &programador);
	printf("Digite as Horas por Programadores: ");
	scanf("%f", &horasprogramador);
	printf("Digite o Custo por hora dos programadores: ");
	scanf("%f", &custohora);
	printf("Custo Infraestrutura: ");
	scanf("%f", &infraestrutura);
	printf("Custo Software: ");
	scanf("%f", &software);
	printf("Digite o custo do Cliente: ");
	scanf("%f", &custocliente);
	printf("Digite o imposto: ");
	scanf("%f", &imposto);
	printf("Digite sua comissao: ");
	scanf("%f", &comissao);
	maodeobra = programador * horasprogramador * custohora;
	custototal = maodeobra + infraestrutura	+ software;
	lucrobruto = custocliente - custototal;
	percentualimposto = custocliente * (imposto/100);
	percentualcomissao = custocliente * (comissao/100);
	lucroliquido = lucrobruto - percentualimposto - percentualcomissao;
	margemlucro = lucroliquido / (custocliente*100);
	printf("==================================");
	printf("\n   RELAT�RIO DO PROJETO  ");
	printf("\n==================================");
	printf("\nProjeto: Sistema de Gest�o Escolar");
	printf("\nProgramadores: %.f",programador);
	printf("\nHoras por programador: %.f",horasprogramador);
	printf("\n----------------------------------");
	printf("\nCUSTOS");
	printf("\nM�o de obra:       R$ %.2f", maodeobra);
	printf("\nInfraestrutura:    R$ %.2f", infraestrutura);
	printf("\nSoftware:          R$ %.2f", software);
	printf("\nCusto total:       R$ %.2f", custototal);
	printf("\n----------------------------------");
	printf("\nRECEITA");
	printf("\nValor contratado:  R$ %.2f", custototal);
	printf("\n----------------------------------");
	printf("\nRESULTADO");
	printf("\nImpostos:          R$ %.2f", percentualimposto);
	printf("\nComiss�o:          R$ %.2f", percentualcomissao);
	printf("\nLucro bruto:       R$ %.2f", lucrobruto);
	printf("\nLucro l�quido:     R$ %.2f", lucroliquido);
	printf("\nMargem de lucro:   %.f %%", margemlucro);
	printf("\n==================================");
}
