#include<stdio.h>

float aluguel, alimentacao, transporte, internet, material, lazer, totdespesa, saldorestante,  percentualbolsa, percentualsobra;

main(){
	printf("BOLSA DE ESTUDOS");
	printf("\nPARABENS VOCE GANHOU UMA BOLSA DE R$1500.00");
	printf("\nDigite o valor do seu aluguel: ");
	scanf("%f", &aluguel);
	printf("Digite sua alimentacao: ");
	scanf("%f", &alimentacao);
	printf("Digite seu valor de transporte: ");
	scanf("%f", &transporte);
	printf("Digite o valor da sua internet: ");
	scanf("%f", &internet);
	printf("Digite o valor do seu material academico: ");
	scanf("%f", &material);
	printf("Digite o valor de lazer: ");
	scanf("%f", &lazer);
	totdespesa = lazer + material + internet + transporte + alimentacao + aluguel;
	saldorestante = 1500 - totdespesa;
	percentualbolsa = (totdespesa/1500) * 100;
	percentualsobra = (saldorestante/1500) * 100;
	printf("A sua despesa foi de R$%.2f", totdespesa);
	printf("\nO seu saldo restante e de R$%.2f", saldorestante);
	printf("\nVoce gastou %.f porcento do valor total", percentualbolsa);
	printf("\nSo lhe restou %.f porcento do valor total", percentualsobra);
	if (saldorestante >= 0){
		printf("\nPARABENS SEU SALDO FOI POSITIVO");
	}
	else{
		printf("\nINFELIZMENTE SEU SALDO FOI NEGATIVO");
		
	}
}
