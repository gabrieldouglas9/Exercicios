#include<stdio.h>

float valordev, horasdev, horareuniao, valorreuniao, imposto, desconto, taxa, valordesenvolvimento, valorreunioes, faturamentobruto, percentualimposto, percentualdesconto, percentualtaxa, faturamentodesconto, valorliquido, valordesconto, valorimposto, valortaxa;

main(){
	printf("FATURAMENTO DE SOFTWARE");
	printf("\nQual valor/h: ");
	scanf("%f", &valordev);
	printf("Quantas horas foi de desenvolvimnto: ");
	scanf("%f", &horasdev);
	printf("Quantas horas de reuniao: ");
	scanf("%f", &horareuniao);
	printf("Qual e o valor da hora de reuniao: ");
	scanf("%f", &valorreuniao);
	printf("Percentual de imposto: ");
	scanf("%f", &imposto);
	printf("Digite o percentual de desconto: ");
	scanf("%f", &desconto);
	printf("Digite a taxa administrativa: ");
	scanf("%f", &taxa);
	valordesenvolvimento = valordev * horasdev;
	valorreunioes = valorreuniao * horareuniao;
	faturamentobruto = valordesenvolvimento + valorreunioes; 
	percentualimposto = (imposto/100);
	percentualdesconto = (desconto/100);
	percentualtaxa = (taxa/100);
	faturamentodesconto = faturamentobruto - faturamentobruto * percentualdesconto; 
	valordesconto = faturamentobruto * percentualdesconto;
	valorimposto = faturamentobruto * percentualimposto;
	valortaxa = faturamentobruto * percentualtaxa;
	valorliquido =  faturamentobruto - valordesconto  - valorimposto - valortaxa;
	printf("O valor do Desenvolvimento do projeto foi de R$%.2f", valordesenvolvimento);
	printf("\nO valor das Reunios foi de R$%.2f", valorreunioes);
	printf("\nO Faturamento bruto foi de R$%.2f", faturamentobruto);
	printf("\nO percentual de imposto foi de R$%.2f", valorimposto);
	printf("\nO percentual de desconto foi de R$%.2f", valordesconto);
	printf("\nO percentual de taxa foi de R$%.2f", valortaxa);
	printf("\nO Valor Liquido do faturamento foi de R$%.2f", valorliquido);
}
